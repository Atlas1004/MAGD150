/*
The red button is a power button
The left gray button is to go up channels (3 channels)
The right one is to go down channels
If you press spacebar while your cursor is on the tv you will break it
*/
function setup() {
  createCanvas(500, 500);
}
let channel = 1;
let on = false, broken = false;
let brokeX=0,brokeY=0;
function draw() {
  background(200);
  stroke(0);
  fill(0);
  rect(25,25,450,400);
  noStroke();
  fill(255,0,0);
  ellipse(50,460,40);
  fill(100);
  rect(100,450,25,25);
  rect(150,450,25,25);
  stroke(0);
  //line(150,450,mouseX,mouseY); //used for debugging buttons
  noStroke();
  
  
  if(on){
    if(broken){
      fill(255,6,169);
      rect(25,25,450,400);
      fill(0,0,255);
      rect(137.5,25,338,400);
      fill(0,255,0);
      rect(250,25,225,400);
      fill(255,0,0);
      rect(362.5,25,112.5,400);
      fill(220);
      beginShape();
      vertex(mouseX-5,mouseY);
      vertex(mouseX-10,mouseY-10);
      vertex(mouseX,mouseY-5);
      vertex(mouseX+10,mouseY-10);
      vertex(mouseX+5,mouseY);
      vertex(mouseX+10,mouseY+10);
      vertex(mouseX,mouseY+5);
      vertex(mouseX-10,mouseY+10);
      endShape(CLOSE);
    }
    else{
      if(channel === 1){
        fill(76,194,250);
        rect(25,25,450,400);
        fill(240,212,24);
        ellipse(400,75,75);
        fill(255);
        ellipse(100,100,25);
        ellipse(110,90,25);
        ellipse(120,105,25);
        ellipse(200,150,25);
        ellipse(210,140,25);
        ellipse(220,155,25);
        fill(63,166,58);
        beginShape();
        vertex(25,400);
        vertex(250,400);
        vertex(300,350);
        vertex(475,350);
        vertex(475,425);
        vertex(25,425);
        endShape(CLOSE);
      }
      else if (channel === 2){
        fill(0);
        rect(25,25,450,400);
        fill(220);
        ellipseMode(CENTER);
        ellipse(250,225,250);
        ellipseMode(CORNER);
        fill(150);
        ellipse(250,225,40);
        ellipse(200,125,50);
        ellipse(150,200,30);
        ellipse(175,270,60);
        fill(220);
        ellipse(255,230,30);
        ellipse(205,130,40);
        ellipse(155,205,20);
        ellipse(180,275,50);
        ellipseMode(CENTER);
      }
      else{
        fill(76,194,250);
        rect(25,25,450,400);
        fill(150);
        beginShape();
        vertex(100,200);
        vertex(100,190);
        vertex(250,90);
        vertex(400,190);
        vertex(400,200);
        endShape(CLOSE);
        fill(164,190,219);
        beginShape();
        vertex(100,400);
        vertex(100,200);
        vertex(250,100);
        vertex(400,200);
        vertex(400,400);
        endShape(CLOSE);
        fill(87,47,8);
        rect(225,300,50,100);
        fill(255,191,23);
        ellipse(270,350,5);
        fill(255);
        rect(140,225,50);
        rect(310,310,50);
        fill(82,100,222);
        rect(145,230,40);
        rect(315,315,40);
        fill(63,166,58);
        rect(25,400,450,25);
      }
    }
  }
}
function mousePressed(){
  if(dist(50,460,mouseX,mouseY)<20){
    if(on===false){
     on=true;
    }
    else{
      on=false;
    }
  }
    if(on){
       if(mouseX>100&&mouseX<125){
      if(mouseY>450&&mouseY<475){
        if(channel<3){
         channel++;
        }
      }
    }
    if(mouseX>150&&mouseX<175){
      if(mouseY>450&&mouseY<475){
        if(channel>1){
          channel--;
        }
      }
    }
  }
}
function keyPressed(){
  if(broken===false){
    if(keyCode===32){//spacebar
      if(mouseX>25&&mouseX<475){
        if(mouseY>25&&mouseY<425){
          broken=true;
          brokeX=mouseX;
          brokeY=mouseY;
        }
      }
    }
  }
}