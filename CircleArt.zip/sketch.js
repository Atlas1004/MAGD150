let mx = 0,my = 0,px = 0,py = 0,fr = 0;
function setup() {
	createCanvas(750, 750);
    background(200);
	let fr = 60;
	frameRate(frames);
}

function draw() {
	let frames = sqrt(3600);
	frameRate(frames);
	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;
	colorMode(RGB, 255, 255, 255, 1);
	stroke(128,0,150, 0.8);
    if(my>py){
      strokeWeight(my-py);
    }
    else{
      strokeWeight(py-my);
    }
	circle(mx, my, pow(mx,0.9));
}