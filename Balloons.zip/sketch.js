function setup() {
  createCanvas(500, 500);
}

function draw() {
  //makes gray background and enables color mode
  background(225);
  colorMode(RGB, 255, 255, 255, 1);
  //makes the background blue like a sky
  noStroke();
  background(10,200,255);
  //clouds
  fill(255,255,255);
  circle(150,100,50);
  circle(175,75,50);
  circle(180,100,50);
  circle(325,200,60);
  circle(350,190,60);
  circle(375,210,60);
  circle(50,300,40);
  circle(50,275,40);
  circle(75,300,40);
  //sun
  fill(255,255,0);
  circle(500,0,200);
  stroke(255,255,0);
  line(395,10,360,10)
  line(395,25,365,30);
  line(405,50,385,60);
  line(420,75,395,90);
  line(430,90,410,110);
  line(450,100,430,130);
  line(470,110,465,140);
  //purple balloon and string
  stroke(1);
  strokeWeight(2);
  fill(200,0,250);
  ellipse(100,100,100,125);
  noFill();
  curve(125, 125, 175, 400, 100,162, 150, 100);
  //yellow balloon and string
  fill(230,230,20);
  triangle(250, 250, 200, 150, 300, 150);
  noFill();
  curve(250,250,275,350,250,250,250,25);
  //red balloon and string
  fill(200,0,0);
  quad(425, 150, 450, 50, 425, 75, 400, 50);
  noFill();
  curve(425,150,425,150,475,450,500,150);
  //ground
  fill(50,200,0);
  beginShape();
  vertex(0,400);
  vertex(200,400);
  vertex(250,350);
  vertex(300,350);
  vertex(400,450);
  vertex(500,450);
  vertex(500,500);
  vertex(0,500);
  endShape(CLOSE);
}